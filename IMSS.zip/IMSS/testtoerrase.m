x=3.5;
if mod(x,1) == 0
   disp('IF')
else
   disp('ELSE')
   
end